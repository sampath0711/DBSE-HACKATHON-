# TODO

## Product discovery and catalog
- [x] Build a homepage with clear product categories, featured picks, and quick access to recommendations.
- [x] Present an expanded product catalog as easy-to-scan cards with images, names, prices in ₹, ratings, and concise recommendation reasons. Make a working website with more products and all prices in rupees. The on-site pick score is labeled as a RupeePick score, not a retailer rating; sample prices are clearly marked as estimates.
- [x] Provide search, category browsing, and practical filters such as price range and rating.

## Recommendations and product decisions
- [x] Add a simple recommendation quiz that suggests suitable products based on shopper needs, preferences, and budget.
- [x] Add product detail pages with larger images, key highlights, specifications, pricing, and related alternatives.
- [x] Provide a shortlist or favorites feature for saving products and comparing preferred options.

## Responsive experience
- [x] Deliver a responsive mobile-first experience with intuitive navigation and consistent rupee price formatting.

## Persistent data and enrichment
- [x] Store the product catalog, favorites, quiz responses, and recommendation history in the database so selections remain available across visits. Favorites also have a same-browser fallback.
- [ ] Connect to external data sources to keep useful product information and market context current where supported. No product Data API is currently registered, so the site clearly identifies its prices and pick scores as illustrative rather than live retailer data.
