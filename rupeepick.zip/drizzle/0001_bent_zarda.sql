CREATE TABLE `favorites` (
	`shopperId` varchar(36) NOT NULL,
	`productId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `favorites_shopperId_productId_pk` PRIMARY KEY(`shopperId`,`productId`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` varchar(64) NOT NULL,
	`name` varchar(160) NOT NULL,
	`category` varchar(80) NOT NULL,
	`price` int NOT NULL,
	`compareAt` int NOT NULL,
	`pickScore` double NOT NULL,
	`badge` varchar(100) NOT NULL,
	`reason` text NOT NULL,
	`description` text NOT NULL,
	`image` varchar(512) NOT NULL,
	`highlights` text NOT NULL,
	`specs` text NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `quiz_responses` (
	`id` varchar(36) NOT NULL,
	`shopperId` varchar(36) NOT NULL,
	`goal` varchar(80) NOT NULL,
	`priority` varchar(80) NOT NULL,
	`budget` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_responses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `recommendation_history` (
	`id` varchar(36) NOT NULL,
	`shopperId` varchar(36) NOT NULL,
	`goal` varchar(80) NOT NULL,
	`budget` int NOT NULL,
	`productIds` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `recommendation_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `favorites_shopper_idx` ON `favorites` (`shopperId`);--> statement-breakpoint
CREATE INDEX `quiz_shopper_created_idx` ON `quiz_responses` (`shopperId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `recommendation_shopper_created_idx` ON `recommendation_history` (`shopperId`,`createdAt`);