import { double, index, int, mysqlEnum, mysqlTable, primaryKey, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const products = mysqlTable("products", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 160 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  price: int("price").notNull(),
  compareAt: int("compareAt").notNull(),
  pickScore: double("pickScore").notNull(),
  badge: varchar("badge", { length: 100 }).notNull(),
  reason: text("reason").notNull(),
  description: text("description").notNull(),
  image: varchar("image", { length: 512 }).notNull(),
  highlights: text("highlights").notNull(),
  specs: text("specs").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const favorites = mysqlTable("favorites", {
  shopperId: varchar("shopperId", { length: 36 }).notNull(),
  productId: varchar("productId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [
  primaryKey({ columns: [table.shopperId, table.productId] }),
  index("favorites_shopper_idx").on(table.shopperId),
]);

export const quizResponses = mysqlTable("quiz_responses", {
  id: varchar("id", { length: 36 }).primaryKey(),
  shopperId: varchar("shopperId", { length: 36 }).notNull(),
  goal: varchar("goal", { length: 80 }).notNull(),
  priority: varchar("priority", { length: 80 }).notNull(),
  budget: int("budget").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("quiz_shopper_created_idx").on(table.shopperId, table.createdAt)]);

export const recommendationHistory = mysqlTable("recommendation_history", {
  id: varchar("id", { length: 36 }).primaryKey(),
  shopperId: varchar("shopperId", { length: 36 }).notNull(),
  goal: varchar("goal", { length: 80 }).notNull(),
  budget: int("budget").notNull(),
  productIds: text("productIds").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => [index("recommendation_shopper_created_idx").on(table.shopperId, table.createdAt)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
