import { useEffect, useMemo, useState } from "react";
import { Link } from "wouter";
import { ArrowDownUp, ArrowRight, Check, ChevronRight, Heart, IndianRupee, Menu, Search, SlidersHorizontal, Sparkles, Star, X } from "lucide-react";
import { toast } from "sonner";
import { CATEGORIES, PRODUCTS, type Product } from "@shared/products";
import { trpc } from "@/lib/trpc";

const formatINR = (value: number) => `₹${Math.round(value).toLocaleString("en-IN")}`;
const DEFAULT_MARKET_STATUS = {
  available: false,
  message: "No live product feed is connected. Prices and pick scores shown here are illustrative, not live retailer data.",
};

type QuizDraft = { goal: string; budget: number; priority: string };
type RecentPick = { goal: string; budget: number; productIds: string[] };

function readIds(key: string): string[] {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function getShopperId(): string {
  try {
    const saved = localStorage.getItem("rupeepick:shopper-id");
    if (saved) return saved;
    const id = crypto.randomUUID();
    localStorage.setItem("rupeepick:shopper-id", id);
    return id;
  } catch {
    return crypto.randomUUID();
  }
}

function readRecentPick(): RecentPick | null {
  try {
    const value = JSON.parse(localStorage.getItem("rupeepick:recent-pick") ?? "null") as RecentPick | null;
    return value && Array.isArray(value.productIds) ? value : null;
  } catch {
    return null;
  }
}

function saveLocalIds(key: string, ids: string[]) {
  try { localStorage.setItem(key, JSON.stringify(ids)); } catch { /* browser storage may be blocked */ }
}

function ProductCard({
  product,
  favorite,
  compared,
  onFavorite,
  onCompare,
}: {
  product: Product;
  favorite: boolean;
  compared: boolean;
  onFavorite: () => void;
  onCompare: () => void;
}) {
  return (
    <article className="product-card">
      <div className="product-art">
        <Link href={`/product/${product.id}`} className="product-image-link" aria-label={`View ${product.name}`}>
          <img src={product.image} alt={`${product.category} product inspiration`} loading="lazy" />
        </Link>
        <span className="product-badge">{product.badge}</span>
        <button className={`icon-button favorite-button${favorite ? " is-favorite" : ""}`} type="button" aria-label={favorite ? `Remove ${product.name} from saved picks` : `Save ${product.name}`} aria-pressed={favorite} onClick={onFavorite}>
          <Heart size={18} fill={favorite ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="product-card-body">
        <div className="product-category-label">{product.category}</div>
        <h3><Link href={`/product/${product.id}`}>{product.name}</Link></h3>
        <p className="product-reason">{product.reason}</p>
        <div className="product-card-bottom">
          <div>
            <strong className="product-price">{formatINR(product.price)}</strong>
            <del className="compare-price">{formatINR(product.compareAt)}</del>
          </div>
          <span className="pick-score" title="RupeePick's illustrative in-site pick score, not a retailer review rating">
            <Star size={14} fill="currentColor" /> {product.pickScore.toFixed(1)} <small>pick</small>
          </span>
        </div>
        <div className="card-actions">
          <Link href={`/product/${product.id}`} className="text-link">See details <ArrowRight size={15} /></Link>
          <button className={`compare-toggle${compared ? " selected" : ""}`} type="button" onClick={onCompare} aria-pressed={compared}>
            {compared ? <Check size={14} /> : null}{compared ? "Comparing" : "Compare"}
          </button>
        </div>
      </div>
    </article>
  );
}

export default function Home() {
  const shopperId = useMemo(getShopperId, []);
  const favoriteStorageKey = `rupeepick:favorites:${shopperId}`;
  const compareStorageKey = `rupeepick:compare:${shopperId}`;
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => readIds(favoriteStorageKey));
  const [compareIds, setCompareIds] = useState<string[]>(() => readIds(compareStorageKey));
  const [recentPick, setRecentPick] = useState<RecentPick | null>(readRecentPick);
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [query, setQuery] = useState("");
  const [maxPrice, setMaxPrice] = useState(5000);
  const [minScore, setMinScore] = useState(0);
  const [sortBy, setSortBy] = useState("recommended");
  const [quizOpen, setQuizOpen] = useState(false);
  const [quizStep, setQuizStep] = useState(1);
  const [quizDraft, setQuizDraft] = useState<QuizDraft>({ goal: "Audio & tech", budget: 2500, priority: "Best value" });
  const [quizResults, setQuizResults] = useState<Product[]>([]);
  const [compareOpen, setCompareOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const catalogQuery = trpc.catalog.list.useQuery(undefined, { initialData: PRODUCTS });
  const catalog = catalogQuery.data ?? PRODUCTS;
  const favoritesQuery = trpc.shopper.favorites.useQuery({ shopperId }, { initialData: favoriteIds, staleTime: 0 });
  const historyQuery = trpc.shopper.history.useQuery({ shopperId }, { initialData: [] });
  const marketQuery = trpc.market.status.useQuery(undefined, { initialData: DEFAULT_MARKET_STATUS });
  const setFavoriteMutation = trpc.shopper.setFavorite.useMutation();
  const saveQuizMutation = trpc.shopper.saveQuiz.useMutation();
  const saveRecommendationMutation = trpc.shopper.saveRecommendation.useMutation();
  const marketStatus = marketQuery.data ?? DEFAULT_MARKET_STATUS;

  useEffect(() => {
    if (favoritesQuery.data) {
      const browserIds = readIds(favoriteStorageKey);
      if (favoritesQuery.data.length === 0 && browserIds.length > 0) return;
      setFavoriteIds(favoritesQuery.data);
      saveLocalIds(favoriteStorageKey, favoritesQuery.data);
    }
  }, [favoritesQuery.data, favoriteStorageKey]);

  useEffect(() => saveLocalIds(compareStorageKey, compareIds), [compareIds, compareStorageKey]);

  const visibleProducts = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();
    const filtered = catalog.filter((product) => {
      const matchesCategory = category === CATEGORIES[0] || product.category === category;
      const matchesSearch = !normalizedQuery || `${product.name} ${product.category} ${product.reason}`.toLowerCase().includes(normalizedQuery);
      return matchesCategory && matchesSearch && product.price <= maxPrice && product.pickScore >= minScore;
    });
    if (sortBy === "price-low") return filtered.sort((a, b) => a.price - b.price);
    if (sortBy === "price-high") return filtered.sort((a, b) => b.price - a.price);
    if (sortBy === "score") return filtered.sort((a, b) => b.pickScore - a.pickScore);
    return filtered.sort((a, b) => b.pickScore - a.pickScore || a.price - b.price);
  }, [catalog, category, maxPrice, minScore, query, sortBy]);

  const savedProducts = catalog.filter((product) => favoriteIds.includes(product.id));
  const comparedProducts = catalog.filter((product) => compareIds.includes(product.id));
  const featuredProducts = ["everyday-buds", "ergonomic-mouse", "steel-bottle"].map((id) => catalog.find((product) => product.id === id)).filter((product): product is Product => Boolean(product));
  const savedHistory = historyQuery.data?.[0];
  const displayedPick: RecentPick | null = recentPick ?? (savedHistory ? { goal: savedHistory.goal, budget: savedHistory.budget, productIds: savedHistory.productIds } : null);
  const recentProducts = displayedPick ? displayedPick.productIds.map((id) => catalog.find((product) => product.id === id)).filter((product): product is Product => Boolean(product)) : [];

  function toggleFavorite(product: Product) {
    const wasSaved = favoriteIds.includes(product.id);
    const next = wasSaved ? favoriteIds.filter((id) => id !== product.id) : [...favoriteIds, product.id];
    setFavoriteIds(next);
    saveLocalIds(favoriteStorageKey, next);
    setFavoriteMutation.mutate({ shopperId, productId: product.id, saved: !wasSaved }, {
      onSuccess: (savedIds) => {
        setFavoriteIds(savedIds);
        saveLocalIds(favoriteStorageKey, savedIds);
      },
      onError: () => toast.message("Saved on this device. Sync will resume when the data service is available."),
    });
  }

  function toggleCompare(productId: string) {
    const exists = compareIds.includes(productId);
    if (exists) {
      setCompareIds(compareIds.filter((id) => id !== productId));
      return;
    }
    if (compareIds.length >= 3) {
      toast.message("Compare up to three picks at a time.");
      return;
    }
    setCompareIds([...compareIds, productId]);
  }

  function runQuiz() {
    const matchingCategory = catalog.filter((product) => product.category === quizDraft.goal);
    const inBudget = catalog.filter((product) => product.price <= quizDraft.budget);
    const pool = matchingCategory.some((product) => product.price <= quizDraft.budget) ? matchingCategory.filter((product) => product.price <= quizDraft.budget) : inBudget.length ? inBudget : catalog;
    const ranked = [...pool].sort((a, b) => {
      const score = (product: Product) => {
        const valueFit = product.price <= quizDraft.budget ? (quizDraft.budget - product.price) / Math.max(quizDraft.budget, 1) * 0.7 : -2;
        const details = `${product.name} ${product.reason} ${product.description} ${product.highlights.join(" ")}`.toLowerCase();
        const priorityFit = quizDraft.priority === "Best value" ? (product.compareAt - product.price) / Math.max(product.compareAt, 1) * 0.18 : quizDraft.priority === "Comfort" ? (/comfort|cushion|contour|walk|ergonomic/.test(details) ? 0.18 : 0) : (/simple|easy|compact|lightweight/.test(details) ? 0.15 : 0);
        return (product.category === quizDraft.goal ? 1.2 : 0) + (product.pickScore / 5) * 0.35 + valueFit + priorityFit;
      };
      return score(b) - score(a) || a.price - b.price;
    }).slice(0, 3);
    setQuizResults(ranked);
    setQuizStep(3);
    const recent = { goal: quizDraft.goal, budget: quizDraft.budget, productIds: ranked.map((product) => product.id) };
    setRecentPick(recent);
    try { localStorage.setItem("rupeepick:recent-pick", JSON.stringify(recent)); } catch { /* optional local copy */ }
    saveQuizMutation.mutate({ shopperId, ...quizDraft });
    saveRecommendationMutation.mutate({ shopperId, goal: quizDraft.goal, budget: quizDraft.budget, productIds: recent.productIds });
    void historyQuery.refetch();
  }

  function openQuiz() {
    setQuizDraft({ goal: category !== CATEGORIES[0] ? category : "Audio & tech", budget: 2500, priority: "Best value" });
    setQuizStep(1);
    setQuizOpen(true);
  }

  function closeQuiz() {
    setQuizOpen(false);
    setQuizStep(1);
  }

  return (
    <div className="site-shell">
      <header className="site-header">
        <div className="header-inner">
          <Link href="/" className="brand" aria-label="RupeePick home">
            <span className="brand-mark"><IndianRupee size={18} strokeWidth={2.6} /></span>
            <span>rupee<span className="brand-pick">pick</span><small>LESS SCROLL. BETTER PICKS.</small></span>
          </Link>
          <nav className={`main-nav${mobileMenuOpen ? " open" : ""}`} aria-label="Main navigation">
            <a href="#discover" onClick={() => setMobileMenuOpen(false)}>Discover</a>
            <a href="#categories" onClick={() => setMobileMenuOpen(false)}>Categories</a>
            <a href="#saved" onClick={() => setMobileMenuOpen(false)}>Saved <span className="nav-count">{favoriteIds.length}</span></a>
          </nav>
          <div className="header-actions">
            <button className="quiz-header-button" type="button" onClick={openQuiz}><Sparkles size={16} /> Find my pick</button>
            <button className="mobile-menu" type="button" aria-label={mobileMenuOpen ? "Close menu" : "Open menu"} onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>{mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}</button>
          </div>
        </div>
      </header>

      <main>
        <section className="hero-wrap">
          <div className="hero-copy">
            <span className="eyebrow"><span className="eyebrow-dot" /> A LITTLE LESS SCROLLING</span>
            <h1>Find a good pick.<br /><span>Skip the endless scroll.</span></h1>
            <p>Useful everyday finds, easy budget filters, and one clear price in ₹. Start with what you need; we’ll narrow things down.</p>
            <div className="hero-actions">
              <button type="button" className="button-primary" onClick={openQuiz}><Sparkles size={17} /> Find my recommendation</button>
              <a href="#discover" className="button-secondary">Browse all picks <ArrowRight size={17} /></a>
            </div>
            <div className="hero-proof"><span><Check size={15} /> 24 easy-to-scan picks</span><span><Check size={15} /> Shop by budget</span><span><Check size={15} /> Prices in rupees</span></div>
          </div>
          <div className="hero-image" role="img" aria-label="A curated collection of everyday electronics and useful products">
            <div className="hero-image-shade" />
            <div className="hero-image-note"><span className="note-spark"><Sparkles size={15} /></span><span><strong>Useful, not overwhelming</strong><small>Four categories. Simple choices.</small></span></div>
            <div className="hero-floating-price"><span>GOOD FINDS FROM</span><strong>₹349</strong></div>
          </div>
        </section>

        <div className="trust-strip">
          <div><span className="trust-icon"><SlidersHorizontal size={17} /></span><span><strong>Filter your way</strong><small>Category, price & pick score</small></span></div>
          <div><span className="trust-icon"><IndianRupee size={17} /></span><span><strong>Rupees up front</strong><small>No currency conversion</small></span></div>
          <div><span className="trust-icon"><Heart size={17} /></span><span><strong>Keep a shortlist</strong><small>Save and compare favourites</small></span></div>
        </div>

        <section className="discovery-section" id="discover">
          <div className="section-heading">
            <div>
              <span className="eyebrow muted-eyebrow">THE SHORTLIST</span>
              <h2>Good picks, minus the guesswork.</h2>
              <p>Browse by what you need. Filter by what you want to spend.</p>
            </div>
            <button className="quiz-text-link" type="button" onClick={openQuiz}>Take the 3-step quiz <ArrowRight size={17} /></button>
          </div>

          <div className="catalog-notice" role="note">
            <span className="notice-icon"><Sparkles size={16} /></span>
            <div><strong>Sample catalog · estimated prices</strong><span>{marketStatus.message}</span></div>
          </div>

          <div className="featured-block">
            <div className="featured-heading"><div><span className="eyebrow muted-eyebrow">FEATURED PICKS</span><h3>A few easy places to start.</h3></div><a href="#categories" className="text-link">Browse categories <ArrowRight size={14} /></a></div>
            <div className="featured-grid">{featuredProducts.map((product) => <Link key={product.id} href={`/product/${product.id}`} className="featured-pick"><img src={product.image} alt="" loading="lazy" /><span><small>{product.category}</small><strong>{product.name}</strong><b>{formatINR(product.price)}</b></span><ArrowRight size={16} /></Link>)}</div>
          </div>

          <div className="catalog-layout">
            <aside className="filter-panel" aria-label="Product filters">
              <div className="filter-title"><SlidersHorizontal size={17} /><strong>Make it yours</strong><button type="button" className="reset-link" onClick={() => { setCategory(CATEGORIES[0]); setMaxPrice(5000); setMinScore(0); setQuery(""); }}>Reset</button></div>
              <label className="filter-label" htmlFor="price-cap">Your price cap <strong>{formatINR(maxPrice)}</strong></label>
              <input id="price-cap" className="price-range" type="range" min="300" max="5000" step="100" value={maxPrice} onChange={(event) => setMaxPrice(Number(event.target.value))} />
              <div className="range-labels"><span>₹300</span><span>₹5,000+</span></div>
              <div className="filter-divider" />
              <label className="filter-label" htmlFor="score-filter">Minimum pick score</label>
              <select id="score-filter" className="select-control" value={minScore} onChange={(event) => setMinScore(Number(event.target.value))}>
                <option value={0}>Any score</option><option value={4.5}>4.5+ picks</option><option value={4.7}>4.7+ picks</option>
              </select>
              <div className="filter-divider" />
              <p className="filter-help"><Star size={14} fill="currentColor" /> Pick scores are RupeePick's sample sorting guide, not retailer review ratings.</p>
              <div className="filter-prompt"><Sparkles size={17} /><strong>Not sure where to start?</strong><span>Tell us your need and budget. Get a short list.</span><button type="button" onClick={openQuiz}>Take the quick quiz <ArrowRight size={15} /></button></div>
            </aside>

            <div className="catalog-main">
              <div className="category-row" id="categories" aria-label="Browse product categories">
                {CATEGORIES.map((item) => <button type="button" key={item} className={`category-chip${category === item ? " active" : ""}`} onClick={() => setCategory(item)}>{item === CATEGORIES[0] ? <Sparkles size={14} /> : null}{item}</button>)}
              </div>
              <div className="catalog-tools">
                <div className="search-box"><Search size={18} /><input type="search" aria-label="Search products" placeholder="Search picks, categories..." value={query} onChange={(event) => setQuery(event.target.value)} />{query && <button type="button" aria-label="Clear search" onClick={() => setQuery("")}><X size={15} /></button>}</div>
                <div className="sort-wrap"><ArrowDownUp size={15} /><label htmlFor="sort-products">Sort</label><select id="sort-products" value={sortBy} onChange={(event) => setSortBy(event.target.value)}><option value="recommended">Recommended</option><option value="score">Pick score</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option></select></div>
              </div>
              <div className="results-line"><span><strong>{visibleProducts.length}</strong> picks to browse</span><span>Prices shown in ₹</span></div>
              {visibleProducts.length ? <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} favorite={favoriteIds.includes(product.id)} compared={compareIds.includes(product.id)} onFavorite={() => toggleFavorite(product)} onCompare={() => toggleCompare(product.id)} />)}</div> : <div className="empty-state"><Search size={24} /><h3>No picks match those filters</h3><p>Try a higher price cap or clear your search.</p><button type="button" className="button-secondary" onClick={() => { setCategory(CATEGORIES[0]); setMaxPrice(5000); setMinScore(0); setQuery(""); }}>Clear filters</button></div>}
              {catalogQuery.isError && <p className="inline-note">Showing the sample catalog while saved data reconnects.</p>}
            </div>
          </div>
        </section>

        {recentProducts.length > 0 && <section className="recent-section">
          <div className="section-heading compact-heading"><div><span className="eyebrow muted-eyebrow">YOUR LAST SHORTLIST</span><h2>Pick up where you left off.</h2><p>{displayedPick?.goal} · up to {formatINR(displayedPick?.budget ?? 0)}</p></div><button className="text-button" type="button" onClick={openQuiz}>Retake quiz <ArrowRight size={16} /></button></div>
          <div className="mini-recommendations">{recentProducts.map((product) => <Link key={product.id} href={`/product/${product.id}`} className="mini-recommendation"><img src={product.image} alt="" loading="lazy" /><span><small>{product.category}</small><strong>{product.name}</strong><b>{formatINR(product.price)}</b></span><ChevronRight size={17} /></Link>)}</div>
        </section>}

        <section className="saved-section" id="saved">
          <div className="section-heading compact-heading"><div><span className="eyebrow muted-eyebrow">YOUR SHORTLIST <span className="shortlist-count">{favoriteIds.length}</span></span><h2>Keep the ones you like.</h2><p>Save a pick for later, then compare your favourites side by side.</p></div></div>
          {savedProducts.length ? <>
            <div className="saved-summary"><span><Heart size={16} fill="currentColor" /> {savedProducts.length} saved {savedProducts.length === 1 ? "pick" : "picks"}</span>{savedProducts.length > 1 && <button type="button" className="button-secondary small-button" onClick={() => { setCompareIds(savedProducts.slice(0, 3).map((product) => product.id)); setCompareOpen(true); }}>Compare saved picks <ArrowRight size={15} /></button>}</div>
            <div className="product-grid saved-grid">{savedProducts.slice(0, 4).map((product) => <ProductCard key={product.id} product={product} favorite compared={compareIds.includes(product.id)} onFavorite={() => toggleFavorite(product)} onCompare={() => toggleCompare(product.id)} />)}</div>
          </> : <div className="saved-empty"><span className="saved-empty-icon"><Heart size={21} /></span><div><strong>Your shortlist starts here.</strong><p>Tap the heart on any pick to keep it close.</p></div><a href="#discover" className="text-link">Find a pick <ArrowRight size={15} /></a></div>}
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-main"><Link href="/" className="brand footer-brand"><span className="brand-mark"><IndianRupee size={18} strokeWidth={2.6} /></span><span>rupee<span className="brand-pick">pick</span><small>LESS SCROLL. BETTER PICKS.</small></span></Link><p>Simple product discovery, with your budget in mind.</p><button type="button" className="footer-quiz" onClick={openQuiz}><Sparkles size={15} /> Get a recommendation</button></div>
        <div className="footer-bottom"><span>© RupeePick · Made for easier decisions</span><span>Sample prices and pick scores are illustrative. Check current seller details before buying.</span></div>
      </footer>

      {comparedProducts.length > 0 && <div className="compare-dock"><div><span className="dock-icon"><ArrowDownUp size={16} /></span><span><strong>{comparedProducts.length} of 3 for compare</strong><small>{comparedProducts.map((product) => product.name).join(" · ")}</small></span></div><button type="button" className="button-primary small-button" onClick={() => setCompareOpen(true)} disabled={comparedProducts.length < 2}>{comparedProducts.length < 2 ? "Choose one more" : "Compare now"}<ArrowRight size={15} /></button><button type="button" className="dock-clear" aria-label="Clear comparison picks" onClick={() => setCompareIds([])}><X size={16} /></button></div>}

      {quizOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) closeQuiz(); }}>
        <section className="quiz-modal" role="dialog" aria-modal="true" aria-labelledby="quiz-title">
          <button className="modal-close" type="button" aria-label="Close quiz" onClick={closeQuiz}><X size={19} /></button>
          <div className="quiz-kicker"><Sparkles size={16} /> A BETTER SHORTLIST IN THREE STEPS</div>
          <div className="quiz-progress" aria-label={`Step ${quizStep} of 3`}>{[1, 2, 3].map((step) => <span key={step} className={step <= quizStep ? "complete" : ""} />)}</div>
          {quizStep < 3 ? <>
            <span className="quiz-step-label">STEP {quizStep} OF 2</span>
            {quizStep === 1 ? <>
              <h2 id="quiz-title">What are you shopping for?</h2><p className="quiz-description">Pick the kind of thing you need most.</p>
              <div className="quiz-choice-grid">{CATEGORIES.slice(1).map((item) => <button type="button" key={item} className={`quiz-choice${quizDraft.goal === item ? " chosen" : ""}`} onClick={() => setQuizDraft({ ...quizDraft, goal: item })}><span className="choice-icon">{item === "Audio & tech" ? "01" : item === "Home helpers" ? "02" : item === "Work & desk" ? "03" : "04"}</span><strong>{item}</strong>{quizDraft.goal === item && <Check size={16} />}</button>)}</div>
              <button type="button" className="button-primary quiz-next" onClick={() => setQuizStep(2)}>Choose my budget <ArrowRight size={16} /></button>
            </> : <>
              <h2 id="quiz-title">What feels right to spend?</h2><p className="quiz-description">Choose a comfortable ceiling. Every price is shown in ₹.</p>
              <div className="budget-choices">{[750, 1500, 2500, 5000].map((budget) => <button type="button" key={budget} className={quizDraft.budget === budget ? "chosen" : ""} onClick={() => setQuizDraft({ ...quizDraft, budget })}>{budget === 5000 ? "₹5,000+" : `₹${budget.toLocaleString("en-IN")}`}</button>)}</div>
              <fieldset className="priority-field"><legend>What matters most?</legend><div>{["Best value", "Comfort", "Simple to use"].map((priority) => <button type="button" key={priority} className={quizDraft.priority === priority ? "chosen" : ""} onClick={() => setQuizDraft({ ...quizDraft, priority })}>{priority}</button>)}</div></fieldset>
              <div className="quiz-footer-actions"><button type="button" className="text-button" onClick={() => setQuizStep(1)}>Back</button><button type="button" className="button-primary" onClick={runQuiz}>Show my picks <Sparkles size={16} /></button></div>
            </>}
          </> : <>
            <span className="quiz-step-label">YOUR SHORTLIST IS READY</span><h2 id="quiz-title">A few good places to start.</h2><p className="quiz-description">Matched to {quizDraft.goal.toLowerCase()} and your budget up to {formatINR(quizDraft.budget)}.</p>
            <div className="quiz-result-list">{quizResults.map((product, index) => <Link key={product.id} href={`/product/${product.id}`} className="quiz-result" onClick={closeQuiz}><span className="result-rank">0{index + 1}</span><img src={product.image} alt="" /><span className="result-name"><small>{product.badge}</small><strong>{product.name}</strong></span><b>{formatINR(product.price)}</b><ChevronRight size={17} /></Link>)}</div>
            <div className="quiz-disclaimer">Saved on this device. If the database is available, your shortlist and answers sync across visits.</div>
            <div className="quiz-footer-actions"><button type="button" className="text-button" onClick={() => { setQuizStep(1); setQuizResults([]); }}>Start over</button><button type="button" className="button-primary" onClick={closeQuiz}>Done <Check size={16} /></button></div>
          </>}
        </section>
      </div>}

      {compareOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setCompareOpen(false); }}>
        <section className="compare-modal" role="dialog" aria-modal="true" aria-labelledby="compare-title">
          <button className="modal-close" type="button" aria-label="Close comparison" onClick={() => setCompareOpen(false)}><X size={19} /></button>
          <span className="eyebrow muted-eyebrow">SIDE BY SIDE</span><h2 id="compare-title">Compare your picks.</h2><p className="quiz-description">Keep the details in one place while you decide.</p>
          {comparedProducts.length < 2 ? <div className="empty-state compare-empty"><ArrowDownUp size={22} /><p>Choose at least two products using the Compare button on a product card.</p></div> : <div className="comparison-grid" style={{ gridTemplateColumns: `repeat(${comparedProducts.length}, minmax(0, 1fr))` }}>{comparedProducts.map((product) => <div className="comparison-item" key={product.id}><img src={product.image} alt="" /><small>{product.category}</small><strong>{product.name}</strong><b>{formatINR(product.price)}</b><span><Star size={14} fill="currentColor" /> {product.pickScore.toFixed(1)} pick score</span><p>{product.reason}</p><Link href={`/product/${product.id}`} className="text-link" onClick={() => setCompareOpen(false)}>Details <ArrowRight size={14} /></Link><button type="button" className="remove-compare" onClick={() => toggleCompare(product.id)}>Remove</button></div>)}</div>}
          <div className="compare-note">Prices and scores are illustrative. Compare verified retailer listings before buying.</div>
        </section>
      </div>}
    </div>
  );
}
