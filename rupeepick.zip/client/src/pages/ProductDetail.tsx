import { useMemo, useState } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { ArrowLeft, ArrowRight, Check, Heart, IndianRupee, Star } from "lucide-react";
import { toast } from "sonner";
import { PRODUCTS, type Product } from "@shared/products";
import { trpc } from "@/lib/trpc";

const formatINR = (value: number) => `₹${Math.round(value).toLocaleString("en-IN")}`;

function getShopperId() {
  try {
    const stored = localStorage.getItem("rupeepick:shopper-id");
    if (stored) return stored;
    const id = crypto.randomUUID();
    localStorage.setItem("rupeepick:shopper-id", id);
    return id;
  } catch {
    return crypto.randomUUID();
  }
}

function readFavorites(key: string) {
  try {
    const value: unknown = JSON.parse(localStorage.getItem(key) ?? "[]");
    return Array.isArray(value) ? value.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

export default function ProductDetail() {
  const [, params] = useRoute("/product/:productId");
  const [, navigate] = useLocation();
  const shopperId = useMemo(getShopperId, []);
  const storageKey = `rupeepick:favorites:${shopperId}`;
  const catalogQuery = trpc.catalog.list.useQuery(undefined, { initialData: PRODUCTS });
  const favoriteQuery = trpc.shopper.favorites.useQuery({ shopperId }, { initialData: readFavorites(storageKey) });
  const [favoriteIds, setFavoriteIds] = useState<string[]>(() => readFavorites(storageKey));
  const mutation = trpc.shopper.setFavorite.useMutation();
  const product = (catalogQuery.data ?? PRODUCTS).find((item) => item.id === params?.productId);
  const related = (catalogQuery.data ?? PRODUCTS).filter((item) => item.category === product?.category && item.id !== product?.id).slice(0, 3);
  const effectiveFavorites = favoriteQuery.data?.length ? favoriteQuery.data : favoriteIds;
  const isFavorite = Boolean(product && effectiveFavorites.includes(product.id));

  if (!product) {
    return <main className="detail-missing"><div className="brand"><span className="brand-mark"><IndianRupee size={18} /></span><span>rupee<span className="brand-pick">pick</span></span></div><h1>That pick is not here.</h1><p>It may have moved. Browse the current shortlist instead.</p><Link className="button-primary" href="/">Back to picks <ArrowRight size={16} /></Link></main>;
  }

  function toggleFavorite() {
    if (!product) return;
    const currentProduct = product;
    const saved = !isFavorite;
    const next = saved ? [...favoriteIds.filter((id) => id !== currentProduct.id), currentProduct.id] : favoriteIds.filter((id) => id !== currentProduct.id);
    setFavoriteIds(next);
    try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* optional local copy */ }
    mutation.mutate({ shopperId, productId: currentProduct.id, saved }, {
      onSuccess: (ids) => {
        setFavoriteIds(ids);
        try { localStorage.setItem(storageKey, JSON.stringify(ids)); } catch { /* optional local copy */ }
      },
      onError: () => toast.message("Saved on this device. Sync will resume when the data service is available."),
    });
  }

  return (
    <div className="site-shell">
      <header className="site-header"><div className="header-inner">
        <Link href="/" className="brand" aria-label="RupeePick home"><span className="brand-mark"><IndianRupee size={18} strokeWidth={2.6} /></span><span>rupee<span className="brand-pick">pick</span><small>LESS SCROLL. BETTER PICKS.</small></span></Link>
        <nav className="detail-nav"><Link href="/">Shop picks</Link><a href="/#saved">Saved shortlist</a></nav>
        <Link href="/#discover" className="detail-shop-link">Browse catalog <ArrowRight size={15} /></Link>
      </div></header>
      <main className="detail-page">
        <button className="back-link" type="button" onClick={() => navigate("/")}><ArrowLeft size={16} /> Back to picks</button>
        <div className="detail-breadcrumb"><Link href="/">Home</Link><span>/</span><a href="/#categories">{product.category}</a><span>/</span><span>{product.name}</span></div>
        <section className="detail-layout">
          <div className="detail-image-wrap"><img src={product.image} alt={`${product.category} product inspiration`} /><span className="product-badge detail-badge">{product.badge}</span><span className="image-caption">Product inspiration · illustrative image</span></div>
          <div className="detail-copy">
            <span className="eyebrow muted-eyebrow">{product.category.toUpperCase()}</span>
            <h1>{product.name}</h1>
            <div className="detail-score"><span><Star size={16} fill="currentColor" /> {product.pickScore.toFixed(1)}</span><span>RupeePick score</span><span className="score-divider">·</span><span>Curated sample pick</span></div>
            <p className="detail-description">{product.description}</p>
            <div className="detail-price-box"><div><span className="detail-price">{formatINR(product.price)}</span><del>{formatINR(product.compareAt)}</del></div><span className="price-note">Indicative price guide · not a live offer</span></div>
            <p className="detail-reason"><span className="reason-spark"><Check size={15} /></span><span><strong>Why it made the list</strong>{product.reason}</span></p>
            <div className="detail-actions"><button type="button" className={`button-primary${isFavorite ? " saved-button" : ""}`} onClick={toggleFavorite}><Heart size={17} fill={isFavorite ? "currentColor" : "none"} />{isFavorite ? "Saved to shortlist" : "Save to shortlist"}</button><button type="button" className="button-secondary" onClick={() => navigate("/#discover")}>See more picks <ArrowRight size={16} /></button></div>
            <div className="detail-data-note">This is a sample product profile. Price, specifications and pick score are illustrative; check verified retailer information before purchasing.</div>
          </div>
        </section>
        <section className="detail-info-grid">
          <div className="detail-highlights"><span className="eyebrow muted-eyebrow">THE QUICK READ</span><h2>What to know.</h2><ul>{product.highlights.map((highlight) => <li key={highlight}><span className="check-dot"><Check size={13} /></span>{highlight}</li>)}</ul></div>
          <div className="detail-specs"><span className="eyebrow muted-eyebrow">PRODUCT NOTES</span><h2>At a glance.</h2><dl>{Object.entries(product.specs).map(([label, value]) => <div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl></div>
        </section>
        {related.length > 0 && <section className="related-section"><div className="section-heading compact-heading"><div><span className="eyebrow muted-eyebrow">SAME CATEGORY</span><h2>Other picks to weigh up.</h2><p>Take a look at a few nearby alternatives.</p></div><Link href="/#discover" className="text-link">Browse everything <ArrowRight size={15} /></Link></div><div className="related-grid">{related.map((item: Product) => <Link key={item.id} href={`/product/${item.id}`} className="related-card"><img src={item.image} alt="" loading="lazy" /><span><small>{item.badge}</small><strong>{item.name}</strong><b>{formatINR(item.price)}</b></span><ArrowRight size={16} /></Link>)}</div></section>}
      </main>
      <footer className="site-footer"><div className="footer-bottom"><span>© RupeePick · Simple product discovery</span><span>Sample prices are illustrative. Check current seller details before buying.</span></div></footer>
    </div>
  );
}
