import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getCatalogProduct, getFavoriteIds, getRecommendationHistory, listCatalog, saveQuizResponse, saveRecommendation, setFavorite } from "./catalog";

const shopperIdInput = z.string().uuid();

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  catalog: router({
    list: publicProcedure.query(() => listCatalog()),
    get: publicProcedure.input(z.object({ id: z.string().min(1).max(64) })).query(({ input }) => getCatalogProduct(input.id)),
  }),
  shopper: router({
    favorites: publicProcedure.input(z.object({ shopperId: shopperIdInput })).query(({ input }) => getFavoriteIds(input.shopperId)),
    setFavorite: publicProcedure.input(z.object({ shopperId: shopperIdInput, productId: z.string().min(1).max(64), saved: z.boolean() })).mutation(({ input }) => setFavorite(input.shopperId, input.productId, input.saved)),
    saveQuiz: publicProcedure.input(z.object({ shopperId: shopperIdInput, goal: z.string().min(1).max(80), priority: z.string().min(1).max(80), budget: z.number().int().min(100).max(100000) })).mutation(({ input }) => saveQuizResponse(input)),
    saveRecommendation: publicProcedure.input(z.object({ shopperId: shopperIdInput, goal: z.string().min(1).max(80), budget: z.number().int().min(100).max(100000), productIds: z.array(z.string().min(1).max(64)).max(8) })).mutation(({ input }) => saveRecommendation(input)),
    history: publicProcedure.input(z.object({ shopperId: shopperIdInput })).query(({ input }) => getRecommendationHistory(input.shopperId)),
  }),
  market: router({
    status: publicProcedure.query(() => ({ available: false, message: "No live product feed is connected. Prices and pick scores shown here are illustrative, not live retailer data." })),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
