import { and, desc, eq } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { PRODUCTS, type Product } from "../shared/products";
import { favorites, products, quizResponses, recommendationHistory } from "../drizzle/schema";
import { getDb } from "./db";

function parseArray(value: string): string[] {
  try {
    const parsed: unknown = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item): item is string => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function parseSpecs(value: string): Record<string, string> {
  try {
    const parsed: unknown = JSON.parse(value);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return Object.fromEntries(Object.entries(parsed).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
  } catch {
    return {};
  }
}

function fromRow(row: typeof products.$inferSelect): Product {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: row.price,
    compareAt: row.compareAt,
    pickScore: row.pickScore,
    badge: row.badge,
    reason: row.reason,
    description: row.description,
    image: row.image,
    highlights: parseArray(row.highlights),
    specs: parseSpecs(row.specs),
  };
}

export async function listCatalog(): Promise<Product[]> {
  try {
    const db = await getDb();
    if (!db) return PRODUCTS;

    const existing = await db.select({ id: products.id }).from(products).limit(1);
    if (existing.length === 0) {
      await db.insert(products).values(PRODUCTS.map((product) => ({
        id: product.id,
        name: product.name,
        category: product.category,
        price: product.price,
        compareAt: product.compareAt,
        pickScore: product.pickScore,
        badge: product.badge,
        reason: product.reason,
        description: product.description,
        image: product.image,
        highlights: JSON.stringify(product.highlights),
        specs: JSON.stringify(product.specs),
      })));
    }

    const rows = await db.select().from(products);
    return rows.length ? rows.map(fromRow) : PRODUCTS;
  } catch (error) {
    console.warn("[Catalog] Database unavailable; serving the curated sample catalog.", error);
    return PRODUCTS;
  }
}

export async function getCatalogProduct(id: string): Promise<Product | undefined> {
  const catalog = await listCatalog();
  return catalog.find((product) => product.id === id);
}

export async function getFavoriteIds(shopperId: string): Promise<string[]> {
  try {
    const db = await getDb();
    if (!db) return [];
    const rows = await db.select({ productId: favorites.productId }).from(favorites).where(eq(favorites.shopperId, shopperId)).orderBy(desc(favorites.createdAt));
    return rows.map((row) => row.productId);
  } catch (error) {
    console.warn("[Favorites] Could not load saved picks.", error);
    return [];
  }
}

export async function setFavorite(shopperId: string, productId: string, saved: boolean): Promise<string[]> {
  const db = await getDb();
  if (!db) throw new Error("Project database is unavailable.");
  if (saved) {
    await db.insert(favorites).values({ shopperId, productId }).onDuplicateKeyUpdate({ set: { productId } });
  } else {
    await db.delete(favorites).where(and(eq(favorites.shopperId, shopperId), eq(favorites.productId, productId)));
  }
  return getFavoriteIds(shopperId);
}

export async function saveQuizResponse(input: { shopperId: string; goal: string; priority: string; budget: number }) {
  const db = await getDb();
  if (!db) return { saved: false };
  await db.insert(quizResponses).values({ id: randomUUID(), ...input });
  return { saved: true };
}

export async function saveRecommendation(input: { shopperId: string; goal: string; budget: number; productIds: string[] }) {
  const db = await getDb();
  if (!db) return { saved: false };
  await db.insert(recommendationHistory).values({
    id: randomUUID(),
    shopperId: input.shopperId,
    goal: input.goal,
    budget: input.budget,
    productIds: JSON.stringify(input.productIds.slice(0, 8)),
  });
  return { saved: true };
}

export async function getRecommendationHistory(shopperId: string) {
  try {
    const db = await getDb();
    if (!db) return [];
    const rows = await db.select().from(recommendationHistory)
      .where(eq(recommendationHistory.shopperId, shopperId))
      .orderBy(desc(recommendationHistory.createdAt))
      .limit(5);
    return rows.map((row) => ({
      id: row.id,
      goal: row.goal,
      budget: row.budget,
      productIds: parseArray(row.productIds),
      createdAt: row.createdAt,
    }));
  } catch (error) {
    console.warn("[Recommendations] Could not load saved history.", error);
    return [];
  }
}
